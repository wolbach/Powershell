if (!(Get-Module ps2exe)) {
    Install-Module ps2exe
    Import-Module ps2exe
}

if (!(Test-Path "C:\Program Files\WatchDogLogs\")) {
    New-Item 'C:\Program Files\WatchDogLogs' -ItemType Directory
}

do {
    $EXEpath = Read-Host "Pfad zur .exe eingeben:"
    if (Test-Path $EXEpath) {
        $ps1 = Get-Item $EXEpath"WatchDog*.ps1"
        ps2exe -inputFile $ps1 -outputFile $EXEpath+"WatchDog.exe" -x64 -noOutput
        }
} while (!(Test-Path $EXEpath"WatchDog.exe"))

$user = Read-Host "Nutzernamen angeben (Domain\User)"
$pw = Read-Host -AsSecureString -Prompt "Bitte Passwort eingeben"

$Credentials = New-Object System.Management.Automation.PSCredential ($user, $pw)

New-Service -Name WatchDog -StartupType Automatic -BinaryPathName $EXEpath+"WatchDog.exe" -Credential $Credentials